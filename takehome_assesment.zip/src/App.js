import react from "react";
import TableList from "./Components/TableList";
import SearchPage from "./Components/SearchPage";

function App() {
  return (
    <div className="App">
      <SearchPage />
    </div>
  );
}

export default App;
